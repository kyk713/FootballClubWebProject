   
   function checkFields() {
	if (document.getElementById('name').value == ""){
	  alert("Please enter your full name!");
	  return false;
	}
	if (document.getElementById('pw').value == ""){
	  alert("Please enter your password!");
	  return false;
	}
	if (document.getElementById('age').value == ""){
	  alert("Please enter your age!");
	  return false;
	}
	if (document.getElementById('email').value == ""){
	  alert("Please enter your email!");
	  return false;
	}
	if (document.getElementById('telephone').value == ""){
	  alert("Please enter your telephone!");
	  return false;
	}
	
		
    }

	
     
	 
	 function checkemail(){
		 if (document.getElementById('Email').value == ""){
	  alert("Please enter your email!");
	  return false;
	}
	 }
	